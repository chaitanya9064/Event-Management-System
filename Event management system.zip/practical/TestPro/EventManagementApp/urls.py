from django.urls import path
from .views import event,eventlist,HomePage,attendee,LoginPage,LogoutPage,SignupPage,payment_status
urlpatterns = [
    path('',SignupPage,name='signup'),
    path('login/',LoginPage,name='login'),
    path('home/',HomePage,name='home'),
    path('logout/',LogoutPage,name='logout'),
    path('eventlist/',eventlist, name ='List of Events'),
    path('attendeelist/',attendee,name='Attendee list'),
    path('event/', event, name='create_event'),
    path('payment/', payment_status, name='Payment'),

]
